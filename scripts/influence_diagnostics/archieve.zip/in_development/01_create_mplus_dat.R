#!/usr/bin/env Rscript

#' Create Mplus .dat File for σ_sum_w Cross-Validation
#'
#' This script takes the prepared CV data (long format M_data, wide X_covariates)
#' and creates a wide dataset suitable for Mplus IRT calibration with latent
#' regression covariates.
#'
#' Input files (created by 00_prepare_cv_data.R):
#'   - data/temp/cv_M_data.rds: Response data (person_id, item_id, response, age)
#'   - data/temp/cv_J_data.rds: Item metadata (item_id, K, dimension, original_item_id)
#'   - data/temp/cv_X_covariates.rds: Covariate matrix (person_id, x1-x9)
#'   - data/temp/cv_person_map.rds: Person identifier mapping
#'
#' Output files:
#'   - data/temp/cv_mplus_wide.rds: Wide format R dataset
#'   - mplus/cv_calibration.dat: Mplus data file (space-delimited, no headers)
#'   - mplus/cv_calibration_varnames.txt: Variable names reference
#'
#' Column structure:
#'   - id: Sequential person identifier (1:N)
#'   - years: Age in years (centered at 3)
#'   - x1-x9: Covariate design matrix (intercept + 4 main + 4 interactions)
#'   - [lex_equate names]: Item responses (0 to K-1, truncated to 8 chars max)
#'
#' Mplus compatibility:
#'   - Variable names: max 8 characters, alphanumeric + underscore only
#'   - Missing values: NA converted to "."
#'   - Format: Free format (whitespace delimited)
#'
#' Usage:
#'   source("scripts/authenticity_screening/in_development/01_create_mplus_dat.R")
#'   cv_wide <- create_mplus_dataset()

library(dplyr)
library(tidyr)

# Load safe_left_join utility
source("R/utils/safe_joins.R")

# Load Mplus writing functions
source("scripts/irt_scoring/helpers/write_mplus_data.R")

#' Create Mplus-Compatible Wide Dataset
#'
#' @param input_dir Directory containing prepared CV data
#' @param output_dir Directory for Mplus outputs
#' @return Wide data frame with id, years, covariates, and item responses
create_mplus_dataset <- function(input_dir = "data/temp",
                                  output_dir = "mplus") {

  cat("\n")
  cat("================================================================================\n")
  cat("  CREATE MPLUS DATASET FOR σ_sum_w CROSS-VALIDATION\n")
  cat("================================================================================\n")
  cat("\n")

  # ==========================================================================
  # STEP 1: LOAD PREPARED DATA
  # ==========================================================================

  cat("=== STEP 1: LOAD PREPARED DATA ===\n\n")

  M_data_file <- file.path(input_dir, "cv_M_data.rds")
  J_data_file <- file.path(input_dir, "cv_J_data.rds")
  X_covariates_file <- file.path(input_dir, "cv_X_covariates.rds")
  person_map_file <- file.path(input_dir, "cv_person_map.rds")

  if (!file.exists(M_data_file) || !file.exists(J_data_file) ||
      !file.exists(X_covariates_file) || !file.exists(person_map_file)) {
    stop(paste0(
      "Required input files not found. Run 00_prepare_cv_data.R first:\n",
      "  - ", M_data_file, "\n",
      "  - ", J_data_file, "\n",
      "  - ", X_covariates_file, "\n",
      "  - ", person_map_file
    ))
  }

  M_data <- readRDS(M_data_file)
  J_data <- readRDS(J_data_file)
  X_covariates <- readRDS(X_covariates_file)
  person_map <- readRDS(person_map_file)

  cat(sprintf("[Loaded] M_data: %d observations\n", nrow(M_data)))
  cat(sprintf("[Loaded] J_data: %d items\n", nrow(J_data)))
  cat(sprintf("[Loaded] X_covariates: %d persons, %d covariates\n",
              nrow(X_covariates), ncol(X_covariates) - 1))
  cat(sprintf("[Loaded] person_map: %d persons\n", nrow(person_map)))
  cat("\n")

  # ==========================================================================
  # STEP 2: CREATE ITEM NAME MAPPING (LEX_EQUATE → MPLUS COMPATIBLE)
  # ==========================================================================

  cat("=== STEP 2: CREATE ITEM NAME MAPPING ===\n\n")

  # J_data$original_item_id contains lex_equate names (e.g., "DD101", "DD102")
  # Mplus requires max 8 characters - most lex_equate names already fit
  # Truncate if needed and check for collisions

  item_name_map <- J_data %>%
    dplyr::mutate(
      mplus_name = substr(original_item_id, 1, 8),  # Truncate to 8 chars
      mplus_name = gsub("[^A-Za-z0-9_]", "", mplus_name)  # Remove invalid chars
    ) %>%
    dplyr::select(item_id, original_item_id, mplus_name)

  # Check for name collisions after truncation
  duplicate_names <- item_name_map$mplus_name[duplicated(item_name_map$mplus_name)]
  if (length(duplicate_names) > 0) {
    cat("[WARN] Name collisions detected after truncation:\n")
    collision_items <- item_name_map %>%
      dplyr::filter(mplus_name %in% duplicate_names) %>%
      dplyr::arrange(mplus_name)
    print(collision_items)
    stop("Fix name collisions before proceeding (add suffix like _a, _b)")
  }

  cat(sprintf("[Created] Item name mapping: %d items\n", nrow(item_name_map)))
  cat(sprintf("  Original names: %s ... %s\n",
              item_name_map$original_item_id[1],
              item_name_map$original_item_id[nrow(item_name_map)]))
  cat(sprintf("  Mplus names: %s ... %s\n",
              item_name_map$mplus_name[1],
              item_name_map$mplus_name[nrow(item_name_map)]))

  # Check name lengths
  max_name_length <- max(nchar(item_name_map$mplus_name))
  cat(sprintf("  Max name length: %d chars (Mplus limit: 8)\n", max_name_length))

  if (max_name_length > 8) {
    stop("Some item names exceed 8 characters. Fix truncation logic.")
  }

  cat("\n")

  # ==========================================================================
  # STEP 3: PIVOT M_DATA TO WIDE FORMAT
  # ==========================================================================

  cat("=== STEP 3: PIVOT M_DATA TO WIDE FORMAT ===\n\n")

  cat("Pivoting response data from long to wide...\n")

  # Add mplus_name to M_data for pivoting
  M_data_with_names <- M_data %>%
    safe_left_join(
      item_name_map %>% dplyr::select(item_id, mplus_name),
      by_vars = "item_id"
    )

  # Pivot to wide format: one row per person, one column per item
  M_data_wide <- M_data_with_names %>%
    dplyr::select(person_id, mplus_name, response, age) %>%
    tidyr::pivot_wider(
      names_from = mplus_name,
      values_from = response,
      id_cols = c(person_id, age)
    )

  cat(sprintf("[OK] Wide format: %d persons, %d item columns\n",
              nrow(M_data_wide), ncol(M_data_wide) - 2))
  cat("\n")

  # ==========================================================================
  # STEP 4: JOIN COVARIATES
  # ==========================================================================

  cat("=== STEP 4: JOIN COVARIATES ===\n\n")

  # X_covariates has person_id + x1_intercept through x9_no_depression_age_c
  # Rename to x1, x2, ..., x9 for Mplus simplicity
  X_covariates_renamed <- X_covariates %>%
    dplyr::rename(
      x1 = x1_intercept,
      x2 = x2_female,
      x3 = x3_college,
      x4 = x4_above_fpl_185,
      x5 = x5_no_depression,
      x6 = x6_female_age_c,
      x7 = x7_college_age_c,
      x8 = x8_above_fpl_185_age_c,
      x9 = x9_no_depression_age_c
    )

  # Join covariates to wide data
  mplus_wide <- M_data_wide %>%
    safe_left_join(
      X_covariates_renamed,
      by_vars = "person_id"
    ) %>%
    dplyr::rename(
      id = person_id,
      years = age
    ) %>%
    dplyr::select(id, years, x1, x2, x3, x4, x5, x6, x7, x8, x9, dplyr::everything())

  cat(sprintf("[OK] Joined covariates: %d persons, %d total columns\n",
              nrow(mplus_wide), ncol(mplus_wide)))
  cat(sprintf("  Covariates: x1 (intercept), x2-x5 (main effects), x6-x9 (age interactions)\n"))
  cat("\n")

  # ==========================================================================
  # STEP 5: VALIDATION
  # ==========================================================================

  cat("=== STEP 5: VALIDATION ===\n\n")

  # Check for missing person_ids
  if (any(is.na(mplus_wide$id))) {
    stop("ERROR: Some rows have missing person_id (id)")
  }

  # Check for duplicate person_ids
  if (any(duplicated(mplus_wide$id))) {
    stop("ERROR: Duplicate person_ids (id) detected")
  }

  # Check variable name lengths
  all_var_names <- names(mplus_wide)
  long_names <- all_var_names[nchar(all_var_names) > 8]
  if (length(long_names) > 0) {
    cat("[ERROR] Variable names exceed 8 characters:\n")
    print(long_names)
    stop("Fix variable names before writing Mplus file")
  }

  # Check for invalid characters in variable names
  invalid_names <- all_var_names[!grepl("^[A-Za-z0-9_]+$", all_var_names)]
  if (length(invalid_names) > 0) {
    cat("[ERROR] Variable names contain invalid characters:\n")
    print(invalid_names)
    stop("Fix variable names (alphanumeric + underscore only)")
  }

  cat("[OK] All person_ids unique and non-missing\n")
  cat("[OK] All variable names valid for Mplus (max 8 chars, alphanumeric)\n")
  cat(sprintf("[OK] Final dataset: %d persons × %d variables\n",
              nrow(mplus_wide), ncol(mplus_wide)))
  cat("\n")

  # ==========================================================================
  # STEP 6: SAVE OUTPUTS
  # ==========================================================================

  cat("=== STEP 6: SAVE OUTPUTS ===\n\n")

  # Create output directories
  if (!dir.exists(input_dir)) {
    dir.create(input_dir, recursive = TRUE)
  }
  if (!dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
  }

  # Save wide R dataset
  wide_rds_file <- file.path(input_dir, "cv_mplus_wide.rds")
  saveRDS(mplus_wide, wide_rds_file)
  cat(sprintf("[Saved] Wide R dataset: %s\n", wide_rds_file))

  # Save Mplus .dat file (using existing write_dat_file function)
  dat_file <- file.path(output_dir, "cv_calibration.dat")

  cat("\n")
  write_dat_file(
    data = mplus_wide,
    output_path = dat_file,
    identifier_cols = character(0),  # Include all columns (id is kept)
    validate_before_write = TRUE
  )

  # ==========================================================================
  # SUMMARY
  # ==========================================================================

  cat("================================================================================\n")
  cat("  MPLUS DATASET CREATION COMPLETE\n")
  cat("================================================================================\n")
  cat("\n")

  cat("Output files:\n")
  cat(sprintf("  Wide R dataset: %s\n", wide_rds_file))
  cat(sprintf("  Mplus .dat file: %s\n", dat_file))
  cat(sprintf("  Variable names: %s\n",
              sub("\\.dat$", "_varnames.txt", dat_file)))
  cat("\n")

  cat("Dataset structure:\n")
  cat(sprintf("  Persons: %d\n", nrow(mplus_wide)))
  cat(sprintf("  Variables: %d\n", ncol(mplus_wide)))
  cat(sprintf("    - id: Person identifier (1:%d)\n", max(mplus_wide$id)))
  cat(sprintf("    - years: Age in years (%.2f to %.2f)\n",
              min(mplus_wide$years), max(mplus_wide$years)))
  cat(sprintf("    - x1-x9: Covariate design matrix (9 variables)\n"))
  cat(sprintf("    - Items: %d response variables (%s ... %s)\n",
              ncol(mplus_wide) - 11,
              names(mplus_wide)[12],
              names(mplus_wide)[ncol(mplus_wide)]))
  cat("\n")

  cat("Next steps:\n")
  cat("  1. Review variable names in cv_calibration_varnames.txt\n")
  cat("  2. Create Mplus .inp syntax file with MODEL specification\n")
  cat("  3. Run Mplus calibration with latent regression on x1-x9\n")
  cat("\n")

  return(mplus_wide)
}


# ============================================================================
# MAIN EXECUTION (when sourced directly)
# ============================================================================

if (!interactive()) {
  cat("\n")
  cat("################################################################################\n")
  cat("#                                                                              #\n")
  cat("#     CREATE MPLUS DATASET FOR σ_sum_w CROSS-VALIDATION                        #\n")
  cat("#                                                                              #\n")
  cat("################################################################################\n")
  cat("\n")

  cv_wide <- create_mplus_dataset()

  cat("\n")
  cat("[DONE] Mplus dataset creation complete\n")
  cat("\n")
}
