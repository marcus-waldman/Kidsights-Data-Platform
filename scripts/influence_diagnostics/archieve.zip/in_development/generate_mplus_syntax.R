#!/usr/bin/env Rscript

#' Generate Mplus Factor Syntax from Actual CV Data
#'
#' This script reads the prepared J_data (which only contains items that exist
#' in the NE25 database) and generates the correct Mplus factor syntax.
#'
#' Input: data/temp/cv_J_data.rds (from 00_prepare_cv_data.R)
#' Output: Console output with Mplus syntax (copy-paste ready)

library(dplyr)

# Load J_data (item metadata from prepared CV data)
J_data <- readRDS("data/temp/cv_J_data.rds")

cat("\n")
cat("================================================================================\n")
cat("  MPLUS FACTOR SYNTAX FROM ACTUAL CV DATA\n")
cat("================================================================================\n")
cat("\n")

# Split by dimension
psychosocial_items <- J_data %>%
  dplyr::filter(dimension == 1) %>%
  dplyr::arrange(original_item_id) %>%
  dplyr::pull(original_item_id)

developmental_items <- J_data %>%
  dplyr::filter(dimension == 2) %>%
  dplyr::arrange(original_item_id) %>%
  dplyr::pull(original_item_id)

cat(sprintf("Psychosocial items (dimension=1): %d items\n", length(psychosocial_items)))
cat(sprintf("Developmental items (dimension=2): %d items\n", length(developmental_items)))
cat("\n")

# Function to format items with @1 constraint, 6 items per line, max 88 chars
format_mplus_factor <- function(factor_name, item_names, items_per_line = 6) {

  # Add @1 constraint to each item
  constrained_items <- paste0(item_names, "@1")

  # Split into chunks of items_per_line
  n_items <- length(constrained_items)
  n_chunks <- ceiling(n_items / items_per_line)

  lines <- character(n_chunks + 2)  # +2 for header and semicolon line
  lines[1] <- sprintf("%s BY", factor_name)

  for (i in 1:n_chunks) {
    start_idx <- (i - 1) * items_per_line + 1
    end_idx <- min(i * items_per_line, n_items)
    chunk <- constrained_items[start_idx:end_idx]

    # Add semicolon to last line, nothing to others
    if (i == n_chunks) {
      lines[i + 1] <- sprintf("  %s;", paste(chunk, collapse = " "))
    } else {
      lines[i + 1] <- sprintf("  %s", paste(chunk, collapse = " "))
    }
  }

  return(lines)
}

# Generate syntax
cat("================================================================================\n")
cat("PSYCHOSOCIAL FACTOR (fps)\n")
cat("================================================================================\n")
cat("\n")

fps_syntax <- format_mplus_factor("fps", psychosocial_items)
cat(paste(fps_syntax, collapse = "\n"))
cat("\n\n")

cat("================================================================================\n")
cat("DEVELOPMENTAL SKILLS FACTOR (fds)\n")
cat("================================================================================\n")
cat("\n")

fds_syntax <- format_mplus_factor("fds", developmental_items)
cat(paste(fds_syntax, collapse = "\n"))
cat("\n\n")

cat("================================================================================\n")
cat("COMPLETE BIFACTOR MODEL\n")
cat("================================================================================\n")
cat("\n")

cat(paste(fps_syntax, collapse = "\n"))
cat("\n\n")
cat(paste(fds_syntax, collapse = "\n"))
cat("\n\n")
cat("fps@1;  ! Fix factor variance\n")
cat("fds@1;  ! Fix factor variance\n")
cat("fps WITH fds@0;  ! Factors are orthogonal (uncorrelated)\n")
cat("\n")

# Summary statistics
cat("================================================================================\n")
cat("SUMMARY\n")
cat("================================================================================\n")
cat("\n")
cat(sprintf("Total items in model: %d\n", length(psychosocial_items) + length(developmental_items)))
cat(sprintf("  - Psychosocial (fps): %d items\n", length(psychosocial_items)))
cat(sprintf("  - Developmental (fds): %d items\n", length(developmental_items)))
cat("\n")
cat("Note: This syntax only includes items that exist in your NE25 data.\n")
cat("      Items in the codebook but not collected in NE25 are excluded.\n")
cat("\n")
