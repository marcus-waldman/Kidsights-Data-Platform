# Phase 1a: Fit Base 2D IRT Model with Latent Regression (No Weights, No Penalty)
#
# This script fits the 2D IRT model with latent regression (person effects
# predicted by demographics) without authenticity screening. The fitted parameters
# (tau, beta1, delta, beta, eta) are used as warm starts for the penalized models
# in Phase 1b.
#
# Model: authenticity_glmm_latent_regression.stan
#   - 2D graded response model
#   - Latent regression: eta ~ MVN(X*beta, Omega)
#   - Covariates: intercept + female, college, above_fpl_185, no_depression + age_c interactions
#                 (P = 9: 1 intercept + 4 main + 4 age_c interactions, where age_c = age - 3)
#   - Correlated person effects (LKJ(1) prior)
#   - No participant weights
#   - No skewness penalty
#
# Outputs:
#   - fit0_full: Stan fit object
#   - fit0_params.rds: Extracted parameter estimates (includes beta coefficients)

library(rstan)
library(dplyr)

# Source utilities
source("scripts/authenticity_screening/in_development/gh_quadrature_utils.R")

#' Fit Base 2D IRT Model with Latent Regression
#'
#' @param M_data Data frame with columns: person_id, item_id, response, age
#' @param J_data Data frame with columns: item_id, K (num categories), dimension
#' @param X_covariates Data frame with columns: person_id, x1_intercept, x2_female, ..., x9_no_depression_age_c
#'                     (P = 9: intercept + 4 main + 4 age_c interactions, where age_c = age - 3)
#' @param output_dir Directory to save results (default: "output/authenticity_cv")
#' @param init Initial parameter values for optimization (default: 0)
#' @param iter Maximum iterations for L-BFGS optimization (default: 10000)
#' @param algorithm Optimization algorithm to use (default: "LBFGS")
#' @param verbose Print optimization progress (default: TRUE)
#' @param refresh Print update every N iterations (default: 20)
#' @param history_size L-BFGS history size for Hessian approximation (default: 500)
#' @param tol_obj Absolute tolerance for objective function (default: 1e-12)
#' @param tol_rel_obj Relative tolerance for objective function (default: 1)
#' @param tol_grad Absolute tolerance for gradient ||grad|| (default: 0.5)
#' @param tol_rel_grad Relative tolerance for gradient (default: 1e3)
#' @param tol_param Absolute tolerance for parameters ||dx|| (default: 1e-4)
fit_base_model <- function(M_data, J_data, X_covariates,
                           output_dir = "output/authenticity_cv",
                           init = 0, iter = 10000, algorithm = "LBFGS",
                           verbose = TRUE, refresh = 20, history_size = 500,
                           tol_obj = 1e-12, tol_rel_obj = 1, tol_grad = 0.5,
                           tol_rel_grad = 1e3, tol_param = 1e-4) {

  cat("\n")
  cat("================================================================================\n")
  cat("  PHASE 1a: Fitting Base 2D IRT Model with Latent Regression\n")
  cat("================================================================================\n")
  cat("\n")

  # Create output directory
  if (!dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
    cat(sprintf("[OK] Created output directory: %s\n", output_dir))
  }

  # Get unique person_ids and map to 1:N
  unique_person_ids <- unique(M_data$person_id)
  N <- length(unique_person_ids)

  person_map <- data.frame(
    person_id = unique_person_ids,
    new_id = 1:N
  )

  M_data$ivec <- person_map$new_id[match(M_data$person_id, person_map$person_id)]

  # Get age vector (one per person)
  age <- M_data %>%
    dplyr::group_by(ivec) %>%
    dplyr::summarise(age = dplyr::first(age), .groups = "drop") %>%
    dplyr::arrange(ivec) %>%
    dplyr::pull(age)

  # Prepare covariate matrix (must be sorted by person_id to match person_map order)
  X_matrix <- X_covariates %>%
    dplyr::arrange(person_id) %>%
    dplyr::select(x1_female:x8_no_depression_age) %>%
    as.matrix()

  # Validate dimensions
  if (nrow(X_matrix) != N) {
    stop(sprintf("X_covariates has %d rows but N=%d persons. Dimensions must match.",
                 nrow(X_matrix), N))
  }

  # Prepare Stan data
  stan_data <- list(
    M = nrow(M_data),
    N = N,
    J = nrow(J_data),
    P = ncol(X_matrix),  # Number of covariates (9: intercept + 4 main + 4 interactions)
    ivec = M_data$ivec,
    jvec = M_data$item_id,
    yvec = M_data$response,
    age = age,
    X = X_matrix,        # Covariate matrix (N × P)
    K = J_data$K,
    dimension = J_data$dimension
  )

  cat(sprintf("Data summary:\n"))
  cat(sprintf("  N = %d persons\n", stan_data$N))
  cat(sprintf("  M = %d observations\n", stan_data$M))
  cat(sprintf("  J = %d items\n", stan_data$J))
  cat(sprintf("  P = %d covariates\n", stan_data$P))
  cat(sprintf("  Age range: %.2f to %.2f years\n", min(age), max(age)))
  cat("\n")

  # Compile model (if not already compiled)
  model_file <- "models/authenticity_glmm_latent_regression.stan"

  if (!file.exists(model_file)) {
    stop(sprintf("Model file not found: %s", model_file))
  }

  cat(sprintf("Compiling model: %s\n", model_file))
  stan_model <- rstan::stan_model(file = model_file, model_name = "base_2d_irt_latent_regression")
  cat("[OK] Model compiled successfully\n\n")

  # Fit model
  cat(sprintf("Fitting model with %s optimization (max %d iterations)...\n", algorithm, iter))
  cat("This may take 5-15 minutes depending on data size and convergence.\n\n")

  fit_start <- Sys.time()

  fit0_full <- rstan::optimizing(
    stan_model,
    data = stan_data,
    init = 1,
    iter = iter,
    algorithm = algorithm,
    verbose = verbose,
    refresh = refresh,
    history_size = history_size,
    tol_obj = tol_obj,
    tol_rel_obj = tol_rel_obj,
    tol_grad = tol_grad,
    tol_rel_grad = tol_rel_grad,
    tol_param = tol_param
  )

  fit_end <- Sys.time()
  fit_duration <- as.numeric(difftime(fit_end, fit_start, units = "mins"))

  cat("\n")
  cat(sprintf("[OK] Model fitting complete (%.1f minutes)\n", fit_duration))
  cat("\n")

  # Check convergence
  cat("Checking convergence diagnostics...\n")
  return_code <- fit0_full$return_code

  cat(sprintf("  Return code: %d %s\n", return_code,
              ifelse(return_code == 0, "[OK: Converged]", "[WARNING: Did not converge]")))
  cat(sprintf("  Log-posterior: %.2f\n", fit0_full$value))

  if (return_code != 0) {
    warning(sprintf("Optimization did not converge (return_code = %d). Consider adjusting tolerances or increasing iterations.", return_code))
  }

  cat("\n")

  # Extract parameters for warm starting
  cat("Extracting parameters for warm starting...\n")

  # Debug: Print all parameter names to diagnose issues
  all_param_names <- names(fit0_full$par)
  cat(sprintf("  Total parameters in fit: %d\n", length(all_param_names)))

  params <- with(fit0_full,
    list(
      tau = par[grepl("^tau\\[", names(par))],
      beta1 = par[grepl("^beta1\\[", names(par))],
      delta = par[grepl("^delta\\[", names(par))],
      sigma_eta_psychosocial = par[names(par)=="sigma_eta_psychosocial"],  # Extracted from Sigma
      sigma_eta_developmental = par[names(par)=="sigma_eta_developmental"],  # Extracted from Sigma
      # Regression coefficients (P×2 matrix) - exclude beta1
      beta = par[grepl("^beta\\[", names(par))],
      eta_psychosocial = par[grepl("^eta_psychosocial_raw", names(par))],
      eta_developmental = par[grepl("^eta_developmental_raw", names(par))],
      eta_correlation = par[names(par)=="eta_correlation"]
    )
  )

  # Validate extractions
  cat(sprintf("  tau: %d values (expected %d items)\n",
              length(params$tau), stan_data$J))
  cat(sprintf("  beta1: %d values (expected %d items)\n",
              length(params$beta1), stan_data$J))
  cat(sprintf("  delta: %d values (expected 2 dimensions)\n",
              length(params$delta)))
  cat(sprintf("  sigma_eta_psychosocial: %d value (extracted from Sigma)\n",
              length(params$sigma_eta_psychosocial)))
  cat(sprintf("  sigma_eta_developmental: %d value (extracted from Sigma)\n",
              length(params$sigma_eta_developmental)))
  cat(sprintf("  beta: %d values (expected %d for P=%d × 2 dimensions)\n",
              length(params$beta), stan_data$P * 2, stan_data$P))
  cat(sprintf("  eta_psychosocial: %d values (expected %d persons)\n",
              length(params$eta_psychosocial), stan_data$N))
  cat(sprintf("  eta_developmental: %d values (expected %d persons)\n",
              length(params$eta_developmental), stan_data$N))

  # Flag mismatches
  if (length(params$beta) != stan_data$P * 2) {
    warning(sprintf("WARNING: Expected %d beta coefficients but extracted %d",
                    stan_data$P * 2, length(params$beta)))
    cat("  Parameters starting with 'beta':\n")
    print(all_param_names[grepl("^beta", all_param_names)])
  }

  # Save results
  fit_file <- file.path(output_dir, "fit0_full.rds")
  params_file <- file.path(output_dir, "fit0_params.rds")

  saveRDS(fit0_full, fit_file)
  saveRDS(params, params_file)

  cat(sprintf("[OK] Saved fit object: %s\n", fit_file))
  cat(sprintf("[OK] Saved parameters: %s\n", params_file))
  cat("\n")

  # Summary statistics
  cat("Parameter summary:\n")
  cat(sprintf("  tau: mean = %.3f, sd = %.3f, range = [%.3f, %.3f]\n",
              mean(params$tau), sd(params$tau), min(params$tau), max(params$tau)))
  cat(sprintf("  beta1: mean = %.3f, sd = %.3f, range = [%.3f, %.3f]\n",
              mean(params$beta1), sd(params$beta1), min(params$beta1), max(params$beta1)))
  cat(sprintf("  delta: [%.3f, %.3f] (psychosocial, developmental)\n",
              params$delta[1], params$delta[2]))
  cat(sprintf("  sigma_eta_psychosocial (std dev): %.3f\n",
              params$sigma_eta_psychosocial))
  cat(sprintf("  sigma_eta_developmental (std dev): %.3f\n",
              params$sigma_eta_developmental))
  cat(sprintf("  beta (regression coefs): mean = %.3f, sd = %.3f, range = [%.3f, %.3f]\n",
              mean(params$beta), sd(params$beta), min(params$beta), max(params$beta)))
  cat(sprintf("  eta_psychosocial: mean = %.3f, sd = %.3f\n",
              mean(params$eta_psychosocial), sd(params$eta_psychosocial)))
  cat(sprintf("  eta_developmental: mean = %.3f, sd = %.3f\n",
              mean(params$eta_developmental), sd(params$eta_developmental)))
  cat(sprintf("  eta_correlation: %.3f\n", params$eta_correlation))
  cat("\n")

  cat("================================================================================\n")
  cat("  PHASE 1a COMPLETE\n")
  cat("================================================================================\n")
  cat("\n")

  return(fit0_full)
}


# Example usage (commented out - run interactively)
# M_data <- readRDS("data/temp/cv_M_data.rds")           # Columns: person_id, item_id, response, age
# J_data <- readRDS("data/temp/cv_J_data.rds")           # Columns: item_id, K, dimension
# X_covariates <- readRDS("data/temp/cv_X_covariates.rds") # Columns: person_id, x1-x8
# fit0_full <- fit_base_model(M_data, J_data, X_covariates)
